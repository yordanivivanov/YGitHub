﻿using System;

class MarketingFirm
{
    static void Main(string[] args)
    {
        string firstName;
        string familyName;
        byte age;
        char gender;
        ushort idNumber;
        uint uniqueNumber;
    }
}
