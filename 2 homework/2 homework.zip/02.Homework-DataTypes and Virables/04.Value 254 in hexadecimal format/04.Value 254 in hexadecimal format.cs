﻿using System;

class ValueInhexadecimalFormat
{
    static void Main()
    {
        int number = 0xFE;

        Console.WriteLine(number);
        Console.WriteLine("{0:X}", number);
      }
}

