﻿using System;

class BankAccount
{
    static void Main()
    {
            string firstName = "Dimo";
                string middleName = "Ivanov";
                string lastName = "Dimov";
                decimal balance = 1000000;
                string bankName = "Aset";
            string IBAN = "12343";
            string BIC = "BIC12343";
                ulong creditCard1 = 1111;
                ulong creditCard2 = 123123;
                ulong creditCard3 = 334324;
    }
    }

