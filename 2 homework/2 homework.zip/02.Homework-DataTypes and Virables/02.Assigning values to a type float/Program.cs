﻿using System;

class AssigningValuesToATypeFloat
{
    static void Main()
    {
        double number1 = 34.567839023d;
        float number2 = 12.345f;
        double number3 = 8923.1234857d;
        float number4 = 3456.091f;

        Console.WriteLine("{0} {1} {2} {3}", number1, number2, number3, number4);
    }
}
